package com.example.app;

public interface Confectionery {
    public String getDescription();
    public int price();

    public int amount();
}
